package com.io.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class ConferenceReg {
	
	static WebDriver driver;
	public ConferenceReg(WebDriver driver) {
		this.driver=driver;
	}
	
	By firstName=By.name("txtFN");
	By lastName=By.name("txtLN");
	By email=By.name("Email");
	By contactNo=By.name("Phone");
	By noOfPeople=By.name("size");
	By buildingName=By.name("Address");
	By areaName=By.name("Address2");
	By city=By.name("city");
	By state=By.name("state");
	By conferenceAccess=By.name("memberStatus");
	
	public void firstName() {
		System.out.println(driver.getTitle());
		driver.findElement(firstName).sendKeys("vivek");
	}
	
	public void lastName() {
		driver.findElement(lastName).sendKeys("sai");
	}
	
	public void email() {
		driver.findElement(email).sendKeys("abc@gmail.com");
	}
	
	public void contact() {
		driver.findElement(contactNo).sendKeys("9999999999");
	}
	
	public void noOfPeople() {
		Select drpCountry = new Select(driver.findElement(noOfPeople));
		drpCountry.selectByVisibleText("3");
	}
	
	public void buildingName() {
		driver.findElement(buildingName).sendKeys("rohithnivas");
	}
	
	public void areaName() {
		driver.findElement(areaName).sendKeys("mehdipatnam");
	}
	
	public void city() {
		Select drpCountry = new Select(driver.findElement(city));
		drpCountry.selectByVisibleText("Hyderabad");
	}
	
	public void state() {
		Select drpCountry = new Select(driver.findElement(state));
		drpCountry.selectByVisibleText("Telangana");
	}
	
	public void conferenceAccess() {
		WebElement radio1 = driver.findElement(conferenceAccess);
		radio1.click();
	}
	
	public void clickNext() throws InterruptedException {
		driver.findElement(By.linkText("Next")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
	}
}
