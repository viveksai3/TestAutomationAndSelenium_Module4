package com.io.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PaymentDetails {
	WebDriver driver;

	public PaymentDetails(WebDriver driver) {
		this.driver = driver;
	}
	
	By cardHolderName=By.name("txtFN");
	By debitCardNo=By.name("debit");
	By cvvNumber=By.name("cvv");
	By cardExpiryMonth=By.name("month");
	By cardExpiryYear=By.name("year");
	
	public void cardHolderName() {
		driver.findElement(cardHolderName).sendKeys("Vivek");
	}
	
	public void debitCardName() {
		driver.findElement(debitCardNo).sendKeys("111A98");
	}
	
	public void cvvNumber() {
		driver.findElement(cvvNumber).sendKeys("768");
	}
	
	public void cardExpiryMonth() {
		driver.findElement(cardExpiryMonth).sendKeys("August");
	}
	
	public void cardExpiryYear() {
		driver.findElement(cardExpiryYear).sendKeys("2020");
	}
	
	public void clickNext() throws InterruptedException {
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
	}
}
